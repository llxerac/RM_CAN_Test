#include "gpio.h"
#include "tim.h"
void Direction_forward(void);
void Direction_back(void);
void Tim_setCompare(int Tim1, int Tim2, int Tim3, int Tim4);
void Direction_left(void);
void Direction_right(void);
