#ifndef _FAST_MATH_TEST_GROUP_H_
#define _FAST_MATH_TEST_GROUP_H_

/*--------------------------------------------------------------------------------*/
/* Declare Test Groups */
/*--------------------------------------------------------------------------------*/
JTEST_DECLARE_GROUP(fast_math_tests);

#endif /* _FAST_MATH_TEST_GROUP_H_ */
